<?php
$footer='
		<footer class="small">
			<div class="container">
				<p class="text-center py-3 mb-0">Copyright &copy; 2021</p>
			</div>
		</footer>
		
		<script src="../landing-assets/js/jquery-3.5.1.min.js"></script>
		<script src="../landing-assets/js/popper.min.js"></script>
		<script src="../landing-assets/js/bootstrap.min.js"></script>
		<script src="../landing-assets/js/custom.js"></script>
	</body>
</html>	';