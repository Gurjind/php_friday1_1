<?php
$title = 'PHP';
$desc = 'PHP';
$canonical = 'PHP';
$mobile_title = 'PHP';

$content='

	<!-- ##### CONTENT START ##### -->
	

        <!-- Animated Intro
		=============================== -->
		<div id="large-header" class="large-header">
		  <canvas id="demo-canvas" width="1280" height="840"></canvas>
		</div>

		<style>
		  * {
			margin: 0;
			padding: 0;
		}
		.large-header {
			background: #000;
		}
		.large-header canvas {
			width: 100%;
			height: 100%;
		}
		</style>
	<!-- ##### CONTENT END ##### -->
	
	';

require_once '../landing_inc/output_landing.php';